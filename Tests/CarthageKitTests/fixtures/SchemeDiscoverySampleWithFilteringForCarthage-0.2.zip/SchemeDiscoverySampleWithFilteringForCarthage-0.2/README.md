# SchemeDiscoverySampleForCarthage

This is a sample project meant to be used for the test suite of [Carthage](https://github.com/Carthage/Carthage).
