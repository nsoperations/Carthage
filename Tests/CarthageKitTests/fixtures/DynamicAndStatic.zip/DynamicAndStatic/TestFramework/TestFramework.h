//
//  TestFramework.h
//  TestFramework
//
//  Created by Stephen Marquis on 2/22/17.
//
//

@import Foundation;

//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


