//
//  HelloWorld.h
//  HelloWorld
//
//  Created by Werner Altewischer on 06/05/2019.
//  Copyright © 2019 BehindMedia. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HelloWorld.
FOUNDATION_EXPORT double HelloWorldVersionNumber;

//! Project version string for HelloWorld.
FOUNDATION_EXPORT const unsigned char HelloWorldVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloWorld/PublicHeader.h>


