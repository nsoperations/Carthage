//
//  HelloWorld.swift
//  HelloWorld
//
//  Created by Werner Altewischer on 06/05/2019.
//  Copyright © 2019 BehindMedia. All rights reserved.
//

import Foundation

public class World {

    public func hello() {
        print("Hello world!")
    }

}
